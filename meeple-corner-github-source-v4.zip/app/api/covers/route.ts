import { env } from "cloudflare:workers";
import { isValidAdminKey } from "@/lib/admin";
import { json } from "@/lib/http";
export { OPTIONS } from "@/lib/http";
export async function POST(request: Request) {
  if (!isValidAdminKey(request.headers.get("x-admin-key"))) return json(request, { error: "请先通过管理员验证。" }, 401);
  try {
    if (!env.BUCKET) return json(request, { error: "图片存储尚未连接，请暂用 HTTPS 图片链接。" }, 503);
    const file = (await request.formData()).get("file");
    if (!(file instanceof File) || !file.size || file.size > 3*1024*1024) return json(request, { error: "请选择不超过 3 MB 的 PNG、JPG 或 WebP 图片。" }, 400);
    const bytes = new Uint8Array(await file.arrayBuffer());
    const png = bytes[0]===137 && bytes[1]===80 && bytes[2]===78 && bytes[3]===71 && bytes[4]===13 && bytes[5]===10;
    const jpeg = bytes[0]===255 && bytes[1]===216 && bytes[2]===255;
    const webp = new TextDecoder().decode(bytes.slice(0,4))==="RIFF" && new TextDecoder().decode(bytes.slice(8,12))==="WEBP";
    if (!png && !jpeg && !webp) return json(request, { error: "图片格式不支持，请选择 PNG、JPG 或 WebP。" }, 400);
    const key = crypto.randomUUID();
    await env.BUCKET.put("covers/"+key,bytes,{ httpMetadata:{ contentType: png ? "image/png" : jpeg ? "image/jpeg" : "image/webp" } });
    return json(request, { url: "/api/covers/"+key }, 201);
  } catch { return json(request, { error: "图片上传失败，请重试。" }, 500); }
}
