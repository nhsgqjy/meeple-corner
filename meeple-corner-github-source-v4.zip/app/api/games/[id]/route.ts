import { eq } from "drizzle-orm";
import { getDb } from "@/db";
import { games, ratings, votes, roundVotes } from "@/db/schema";
import { isValidAdminKey } from "@/lib/admin";
import { validGameInput } from "@/lib/boardgame";
import { json } from "@/lib/http";
export { OPTIONS } from "@/lib/http";
type Context = { params: Promise<{ id: string }> };
export async function PATCH(request: Request, context: Context) {
  if (!isValidAdminKey(request.headers.get("x-admin-key"))) return json(request, { error: "请先通过管理员验证。" }, 401);
  try {
    const { id } = await context.params;
    const parsed = validGameInput(await request.json() as Record<string, unknown>);
    if ("error" in parsed) return json(request, { error: parsed.error }, 400);
    const [game] = await getDb().update(games).set(parsed.value).where(eq(games.id,id)).returning();
    return game ? json(request, { game }) : json(request, { error: "找不到这款桌游。" }, 404);
  } catch { return json(request, { error: "保存失败，请重试。" }, 500); }
}
export async function DELETE(request: Request, context: Context) {
  if (!isValidAdminKey(request.headers.get("x-admin-key"))) return json(request, { error: "请先通过管理员验证。" }, 401);
  try {
    const { id } = await context.params;
    const db = getDb();
    await db.batch([db.delete(roundVotes).where(eq(roundVotes.gameId,id)),db.delete(votes).where(eq(votes.gameId,id)),db.delete(ratings).where(eq(ratings.gameId,id)),db.delete(games).where(eq(games.id,id))]);
    return json(request, { ok: true });
  } catch { return json(request, { error: "删除失败，请重试。" }, 500); }
}
