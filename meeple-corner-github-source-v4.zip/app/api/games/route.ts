import { desc, eq } from "drizzle-orm";
import { getDb } from "@/db";
import { games, ratings, votes, votingRounds, roundVotes } from "@/db/schema";
import { isValidAdminKey } from "@/lib/admin";
import { validGameInput } from "@/lib/boardgame";
import { json } from "@/lib/http";
export { OPTIONS } from "@/lib/http";
const starterGames = [
  { id: "azul", title: "花砖物语", category: "策略 · 拼图", players: "2–4", minutes: 35, complexity: "轻松", description: "把彩色瓷砖铺满宫殿墙面，漂亮又有一点点心机。", symbol: "✿", accent: "blue" },
  { id: "splendor", title: "璀璨宝石", category: "策略 · 引擎构筑", players: "2–4", minutes: 30, complexity: "轻松", description: "收集宝石、招揽贵族，用最少的行动搭起财富引擎。", symbol: "✦", accent: "sage" },
  { id: "catan", title: "卡坦岛", category: "经营 · 交易", players: "3–4", minutes: 60, complexity: "适中", description: "掷骰收资源，和朋友谈一笔刚刚好的交易。", symbol: "⌂", accent: "gold" },
  { id: "carcassonne", title: "卡卡颂", category: "策略 · 拼图", players: "2–5", minutes: 40, complexity: "轻松", description: "一块块铺出中世纪的城堡、道路与田野。", symbol: "▧", accent: "terracotta" },
  { id: "avalon", title: "阿瓦隆", category: "派对 · 推理", players: "5–10", minutes: 30, complexity: "轻松", description: "隐藏身份、互相试探，圆桌上的表情都是线索。", symbol: "♜", accent: "plum" },
  { id: "wingspan", title: "展翅翱翔", category: "策略 · 自然", players: "1–5", minutes: 60, complexity: "适中", description: "在一座安静的鸟类保护区里，慢慢发展自己的生态。", symbol: "⌁", accent: "rose" },
];

async function seedIfEmpty(db: ReturnType<typeof getDb>) {
  const existing = await db.select({ id: games.id }).from(games).limit(1);
  if (existing.length) return;
  await db.insert(games).values(starterGames).onConflictDoNothing();
}

export async function GET(request: Request) {
  try {
    const db = getDb(); await seedIfEmpty(db);
    const userId = new URL(request.url).searchParams.get("userId");
    const [gameRows, wantRows, ratingRows, rounds] = await Promise.all([
      db.select().from(games).orderBy(desc(games.createdAt), desc(games.id)),
      db.select().from(votes), db.select().from(ratings),
      db.select().from(votingRounds).orderBy(desc(votingRounds.createdAt)).limit(20),
    ]);
    const currentRound = rounds.find(r => r.isActive) || null;
    const ballots = currentRound ? await db.select().from(roundVotes).where(eq(roundVotes.roundId, currentRound.id)) : [];
    const data = gameRows.map(game => {
      const wants = wantRows.filter(v => v.gameId === game.id);
      const scores = ratingRows.filter(r => r.gameId === game.id);
      const currentVotes = ballots.filter(v => v.gameId === game.id);
      return { ...game, isNew: !starterGames.some(g => g.id === game.id),
        wantCount: wants.length, myWant: wants.some(v => v.userId === userId),
        voteCount: currentVotes.length, myVote: currentVotes.some(v => v.userId === userId),
        ratingCount: scores.length, averageRating: scores.length ? scores.reduce((a,r) => a+r.score,0)/scores.length : 0,
        myRating: scores.find(r => r.userId === userId)?.score || 0 };
    });
    return json(request, { games: data, currentRound, participantCount: new Set(ballots.map(v => v.userId)).size, roundHistory: rounds.filter(r => !r.isActive) });
  } catch { return json(request, { error: "目录加载失败，请稍后重试。" }, 503); }
}
export async function POST(request: Request) {
  if (!isValidAdminKey(request.headers.get("x-admin-key"))) return json(request, { error: "请先通过管理员验证。" }, 401);
  try {
    const parsed = validGameInput(await request.json() as Record<string, unknown>);
    if ("error" in parsed) return json(request, { error: parsed.error }, 400);
    const [game] = await getDb().insert(games).values({ id: crypto.randomUUID(), ...parsed.value }).returning();
    return json(request, { game }, 201);
  } catch { return json(request, { error: "新增失败，请重试。" }, 500); }
}
