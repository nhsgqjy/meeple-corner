# 暖桌 · 今晚玩什么？

供朋友聚会使用的桌游目录、长期想玩清单、分轮投票和评分网页。支持桌面和手机。

## 使用

- 推荐、全部、人气、上新属于目录视图；游戏类型可以独立筛选。
- 心形按钮收藏想玩，棋子按钮参加本轮投票。每人每轮可投多款，每款一票，可分别取消。
- 管理员可以新开投票、维护条目、设置推荐、上传封面或填写 HTTPS 封面链接。
- 评分为 1–5 星，每人每款一条，可修改。

## 本地开发

Node.js 22.13+，安装依赖后运行 npm run dev。
数据库迁移请按顺序应用 drizzle/ 中的 SQL，使用 DB 绑定和 .wrangler/state 本地持久化目录。
本地管理口令保存在未跟踪的 .dev.vars，格式为 ADMIN_KEY=你的口令。

## 构建

- npm run build：Cloudflare Worker 服务端与同源网页。
- npm run build:pages：GitHub Pages 静态前端，输出 pages-dist。

## 部署

见 DEPLOYMENT.md。GitHub Actions 工作流位于 .github/workflows/deploy-pages.yml。
DB 和 BUCKET 分别连接 D1 与 R2。生产管理口令使用服务端秘密配置，不能写进前端或仓库。
