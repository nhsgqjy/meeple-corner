# 暖桌部署

## GitHub Pages

1. 将源码推送到 GitHub 仓库的 main 分支。
2. 仓库 Settings → Pages → Source 选择 GitHub Actions。
3. .github/workflows/deploy-pages.yml 会构建并发布页面。
4. API_BASE_URL 仓库变量指定动态服务地址，默认连接现有服务。不要将管理口令设置为前端变量。
5. 若使用其他 GitHub 用户名，在服务端 PUBLIC_ORIGIN 中加入该 GitHub Pages 的完整 origin，再部署服务端。

前端：npm run build:pages，输出 pages-dist/。
服务端：npm run build，输出 dist/，运行于 Cloudflare Workers，使用 D1 和 R2。

## 配置

- ADMIN_KEY：服务端管理口令，必须使用秘密配置。本地使用未跟踪的 .dev.vars。
- PUBLIC_ORIGIN：允许访问接口的前端域名，多个 origin 用逗号分隔。
- DB：D1 绑定，保存目录、长期想玩、评分、轮次和本轮选票。
- BUCKET：R2 绑定，保存上传的封面图片。

GitHub Pages 只运行静态前端，无法执行这些动态接口。前端发布不会清空服务端数据。不要提交 .dev.vars、.env、.wrangler 或私密配置。
